function [iterk, s_hat] = gpm(s,y,H,u,rho,Es,l)
%   Maximum likehood detector
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
% Exact solver for the problem
% min ||y -H s_hat||_2
% s.t.  [s_hat]_i is an odd integer, for i=1,...,N.  
%
% usage : [s_hat] = ml(y,H,u); or
%         [s_hat] = ml(y,H,u, radius); or
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- u - symbol bound that is a positive odd integer.
% -- radius - radius parameter of the sphere decoding algorithm;
%             unspecified or a positive number.
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================
%s=randi(u+1,2*N,1);s=2*s-u-2;
% 
[M,N] = size(H);

wk = (H'*H+rho^2/Es*eye(N))\(H'*y);
wk=max(wk,-u);
wk=min(wk,u);
wk=round(wk);

iterk=0;

itermax=150;
w=zeros(N,itermax);
  w(:,1) = s(1:N)+sqrt(-1)*s(N+1:2*N);
% w(:,1) =  wk;

Ss=M+rho^2/Es;
for k =1:itermax
    gradk=H'*(H*w(:,k)-y);
    wk=w(:,k)-l*gradk/Ss;
    wr=real(wk);
    wr=min(wr,u*ones(N,1));
    wr=max(wr,-u*ones(N,1));
    wr=2*round((wr-1)/2)+1;
    wi=imag(wk);
    wi=min(wi,u*ones(N,1));
    wi=max(wi,-u*ones(N,1));
    wi=2*round((wi-1)/2)+1;
    s=wr+1i*wi;
    s_hat=[wr;wi];

    for i=1:k
        if s==w(:,i)
            return;
        end
    end
    w(:,k+1)=s;
    iterk=iterk+1;
end
