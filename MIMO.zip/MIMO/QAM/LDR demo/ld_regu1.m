function [w] = ld_regu(y,H,u,N,rho)
%   Regularized lattice decoding
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
% Exact solver for the problem
% min ||y -H s_hat||_2^2 + s_hat^T T s_hat
% s.t.  -u<=[s_hat]_i<=u, [s_hat]_i is an odd integer
%            for i=1,...,N.  
%
% usage : [s_hat] = ld_regu(y,H,T,u); or
%         [s_hat] = ld_regu(y,H,T,u, radius); or
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- T - positive semi-definite regularization matrix of dimension N by N
% -- u - symbol bound that is a positive odd integer.
% -- radius - radius parameter of the sphere decoding algorithm;
%             unspecified or a positive number.
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

wk = (H'*H+rho^2*eye(N))\(H'*y);
wr=real(wk);
    wr=min(wr,u*ones(N,1));
    wr=max(wr,-u*ones(N,1));
    wr=2*round((wr-1)/2)+1;
    wi=imag(wk);
    wi=min(wi,u*ones(N,1));
    wi=max(wi,-u*ones(N,1));
    wi=2*round((wi-1)/2)+1;
    w=[wr;wi];