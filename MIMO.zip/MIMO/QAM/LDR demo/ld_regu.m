function [s_hat] = ld_regu(y,H,T,u,radius)
%   Regularized lattice decoding
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
% Exact solver for the problem
% min ||y -H s_hat||_2^2 + s_hat^T T s_hat
% s.t.  -u<=[s_hat]_i<=u, [s_hat]_i is an odd integer
%            for i=1,...,N.  
%
% usage : [s_hat] = ld_regu(y,H,T,u); or
%         [s_hat] = ld_regu(y,H,T,u, radius); or
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- T - positive semi-definite regularization matrix of dimension N by N
% -- u - symbol bound that is a positive odd integer.
% -- radius - radius parameter of the sphere decoding algorithm;
%             unspecified or a positive number.
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

%number of tx symbols
N=size(H,2);

%triangularize the channel
R=chol(H'*H+T);
y=R'\(H'*y);

%shift and scale
y=(y+R*ones(N,1))/2;

if nargin<=4
    radius=norm(y- R*round(R\y))^2+1e-7;
else
    radius=radius/4;    
end;

%LLL for speeding up sphere decoder
[Qe,Re,Ue]=lll(eye(N),R,3/4);     
%make sure the diagonals of Re are positive
temp=diag(sign(diag(Re)));
Re=temp*Re;
Qe=Qe*temp;
ye=Qe'*y;



%solve the problem min ||ye - Re *z||_2 s.t. z are integers

info=-1;
while (info==-1)
    [z,info]=sd_search(ye,Re,radius,-inf,inf);
    radius=2*radius;
end;

%shift and scale
s_hat=2*Ue*z-1;

%symbol bound
s_hat=max(s_hat,-u);
s_hat=min(s_hat,u);

