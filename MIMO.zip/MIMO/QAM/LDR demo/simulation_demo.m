clear; close all; clc;
%% Demonstration of the Lagrangian dual relaxation (LDR) detector
% This program performs Monte-carlo simulation on the SER
% performance of LDR detectors in QAM constellation.
% 
%   written by Jiaxian Pan and Wing-Kin Ma.
%   last updated on Nov. 25, 2013

%%
N = 64; M = 128; % N - number transmit symbols, M - receive dimension.
QAM_size=16;     %QAM size
LDR_iter=5;     %No. of iterations in the sugradient method in LDR
SNR = 6:3:18;   %SNR in dB
max_no_simulations = 1e6; % No. of Monte-carlo simulations used


%-------------------------
sigma_snr = sqrt( N*10 .^ ( - (SNR) / 10 ) ); % MMSE coefficient.
u=sqrt(QAM_size)-1;         %symbol bound
Es=2/3*(QAM_size-1);        %average energy of a QAM symbol

%detected symbols
sc_nld = zeros(N,1); 
sc_mmse_ld = zeros(N,1); 
sc_ldr_ld = zeros(N,1); 
sc_ml = zeros(N,1); 
sc_lra_zf_df = zeros(N,1); 
sc_lra_mmse_df = zeros(N,1); 
sc_ldr_lra_df = zeros(N,1); 
sc_zf_df = zeros(N,1); 

s_nld = zeros(2*N,1); 
s_mmse_ld = zeros(2*N,1); 
s_ldr_ld = zeros(2*N,1); 
s_ml = zeros(2*N,1); 
s_lra_zf_df = zeros(2*N,1); 
s_lra_mmse_df = zeros(2*N,1); 
s_ldr_lra_df = zeros(2*N,1); 
s_zf_df = zeros(2*N,1); 


%variables for storing the SERs
ser_nld = zeros(length(SNR),1); 
ser_mmse_ld = zeros(length(SNR),1); 
ser_ldr_ld = zeros(length(SNR),1); 
ser_ml = zeros(length(SNR),1); 
ser_lra_zf_df = zeros(length(SNR),1); 
ser_lra_mmse_df = zeros(length(SNR),1); 
ser_ldr_lra_df = zeros(length(SNR),1); 
ser_zf_df = zeros(length(SNR),1); 




for snr_pt = 1 : length(SNR)
    wb= waitbar(0,[int2str(snr_pt) '/' int2str(length(SNR))]);
    max_no_simulations=5*SNR(snr_pt)*1e2;
    for simulation_no = 1 : max_no_simulations
        waitbar(simulation_no/max_no_simulations,wb);
        
        %-----------set up channels, tx & rx signals , etc-------------
        % Generate QAM symbols
        s=randi(u+1,2*N,1);s=2*s-u-2;s_c= s(1:N)+sqrt(-1)*s(N+1:2*N);
        
        % generate the random channel
        H_c = (1/sqrt(2))* (randn(M,N) + 1i*randn(M,N));
        % generate the output vector
        y_c = H_c*s_c + (sigma_snr(snr_pt)*sqrt(Es)/sqrt(2))*(randn(M,1)+1i*randn(M,1));
        
        rho = sigma_snr(snr_pt)*sqrt(Es);
        % Complex to real conversion
        y = [real(y_c); imag(y_c)]; H = [real(H_c) -imag(H_c); imag(H_c) real(H_c)];
        
        %--------detectors------------------
        
        %ZF DF
        [s_zf_df] = zf_df(y,H,u);
        
        %LRA-ZF-DF
       s_lra_zf_df=lra_df_regu(y,H,zeros(2*N),u);
        
        %LRA-MMSE-DF
       s_lra_mmse_df=lra_df_regu(y,H,diag(sigma_snr(snr_pt)^2*ones(2*N,1)),u);
        
        %LDR-LRA-DF
        %s_ldr_lra_df=ldr_lra_df(y,H,u,LDR_iter);
        
        

%         %naive lattice decoding
%         s_nld=ld_regu(y,H,zeros(2*N),u);
%          
%         %MMSE lattice decoding
        s_mmse_ld=ld_regu1(y_c,H_c,u,N,rho);
%           
%         %LDR LD
%         s_ldr_ld=ldr_ld(y,H,u,LDR_iter);
%          
%         %ML
         stepsize = 0.87-0.006*SNR(snr_pt);
%         stepsize = 1;
         iternum=0;
        [iternum,s_ml]=gpm(s_lra_mmse_df,y_c,H_c,u,rho,Es,stepsize);
        
        
        
        %-------count the error-------------
        %real to complex conversion
        sc_zf_df=s_zf_df(1:N)+sqrt(-1)*s_zf_df(N+1:2*N);
        sc_lra_zf_df=s_lra_zf_df(1:N)+sqrt(-1)*s_lra_zf_df(N+1:2*N);
        sc_lra_mmse_df=s_lra_mmse_df(1:N)+sqrt(-1)*s_lra_mmse_df(N+1:2*N);
        sc_nld=s_nld(1:N)+sqrt(-1)*s_nld(N+1:2*N);
        sc_mmse_ld=s_mmse_ld(1:N)+sqrt(-1)*s_mmse_ld(N+1:2*N);
        sc_ml=s_ml(1:N)+sqrt(-1)*s_ml(N+1:2*N);
        sc_ldr_lra_df=s_ldr_lra_df(1:N)+sqrt(-1)*s_ldr_lra_df(N+1:2*N);
        sc_ldr_ld=s_ldr_ld(1:N)+sqrt(-1)*s_ldr_ld(N+1:2*N);
        
        %count errors
        ser_zf_df(snr_pt)=ser_zf_df(snr_pt)+sum(sc_zf_df~=s_c);
        ser_lra_zf_df(snr_pt)=ser_lra_zf_df(snr_pt)+sum(sc_lra_zf_df~=s_c);
        ser_lra_mmse_df(snr_pt)=ser_lra_mmse_df(snr_pt)+sum(sc_lra_mmse_df~=s_c);
        ser_mmse_ld(snr_pt)=ser_mmse_ld(snr_pt)+sum(sc_mmse_ld~=s_c);
        ser_ml(snr_pt)=ser_ml(snr_pt)+sum(sc_ml~=s_c);
        ser_ldr_ld(snr_pt)=ser_ldr_ld(snr_pt)+sum(sc_ldr_ld~=s_c);
        
        ser_nld(snr_pt)=ser_nld(snr_pt)+iternum;
        if simulation_no == 1
            ser_ldr_lra_df(snr_pt)=iternum;
        elseif ser_ldr_lra_df(snr_pt)<iternum;
            ser_ldr_lra_df(snr_pt)=iternum;
        end

    end
    ser_zf_df(snr_pt)=ser_zf_df(snr_pt)/(max_no_simulations*N);
ser_lra_zf_df(snr_pt)=ser_lra_zf_df(snr_pt)/(max_no_simulations*N);
ser_lra_mmse_df(snr_pt)=ser_lra_mmse_df(snr_pt)/(max_no_simulations*N);
ser_nld(snr_pt)=ser_nld(snr_pt)/(max_no_simulations);
ser_mmse_ld(snr_pt)=ser_mmse_ld(snr_pt)/(max_no_simulations*N);
ser_ml(snr_pt)=ser_ml(snr_pt)/(max_no_simulations*N);

ser_ldr_ld(snr_pt)=ser_ldr_ld(snr_pt)/(max_no_simulations*N);

    close(wb);
end

%compute the SER
% ser_zf_df=ser_zf_df/(max_no_simulations*N);
% ser_lra_zf_df=ser_lra_zf_df/(max_no_simulations*N);
% ser_lra_mmse_df=ser_lra_mmse_df/(max_no_simulations*N);
% ser_nld=ser_nld/(max_no_simulations);
% ser_mmse_ld=ser_mmse_ld/(max_no_simulations*N);
% ser_ml=ser_ml/(max_no_simulations*N);
% ser_ldr_ld=ser_ldr_ld/(max_no_simulations*N);


% plot the SER
semilogy( SNR,ser_zf_df,'-+k', SNR,ser_mmse_ld,'--^m',SNR, ser_lra_zf_df,'-ob', SNR, ser_lra_mmse_df,'-sm',SNR,ser_ml,'-pr'); 
grid on;
legend('ZF DF','MMSE','LRA ZF DF', 'LRA MMSE DF','GPM');
xlabel('SNR (dB)'); ylabel('SER');
title(['M=' int2str(M) ' ' 'N=' int2str(N) ' ' int2str(QAM_size) '-QAM']);

