=================================================================
=         Lagriangian Dual Relaxation (LDR) detector	=
=         written by Jiaxian Pan and Wing-kin Ma		= 
=         last updated on : 25-11-2013				=
=================================================================

Installation:
Extract every file to a folder, run MATLAB and execute compile.m to comile the c files

The archive contains the following files :



1. simulation_demo.m
- a short program for demonstrating the SER performance of the LDR detector.

2. zf_df.m
- zero-forcing decision-feedback detector

3. lra_df_regu.m
- regularized lattice reduction aided decision feedback detector

4. ldr_lra_df.m
- Lagrangianl dual relaxation with lattice reducion aided decision feedback detector

5. ld_regu.m
- regularized lattice decoding

6. ldr_ld.m
- Lagrangian dual relaxation with lattice decoding

7. box_relaxation.m
- a master function for solving the box relaxation problem

8. ml.m
- maximum likelihood detector

9. compile.m
- a short program to compile all the c file

10. sd_search.c
- sphere decoding algorithm

11.lll.c
- Lenstra-Lenstra-Lovasz (LLL) reduction algorithm

12. df_u.c
- an algorithm of decision feedback on a bounded odd integer region

13. df.c
- an algorithm of decision feedback on integers

14. br_solver.c
- active set method for solving the box relaxation problem

15. br_bounding_info.c
- an auxiliarty function of generating initialization for br_solver

16. readme.txt
- the text file you are reading

