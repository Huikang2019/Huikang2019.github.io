function [lambda,s_hat] =box_relaxation(y,H,u)
%   Box relaxation via active set method
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
% Exact solver for the problem
% min  ||y -H s_hat||_2
% s.t.  [s_hat]_i^2<=u^2 for i=1,...,N.  
%
% usage : [lambda, s_hat] = box_relaxation(y,H,u);
% ========================================================================
%
% Input parameters :
% -- y - a vector of dimensions M by 1, 
% -- H - a matrix of dimension M by N.
% -- u - a positive odd integer.
%
% Output parameters:
% -- lambda is the dual variable associated with the constraint
% -- s_hat is the solution.
% =======================================================================

        q=size(H,2);
        tic
        HH=H'*H;
        Hy=H'*y;
        R=chol(HH);
        y=R'\(Hy);
        
        zf_symb=R\y; %use ZF as initialization
        istate=br_bounding_info(zf_symb,u); %compute the bounding info. of zf solution
        
        if (istate(q+2)==0) %the zf solution is feasible, and thus the zf soltuion is optimal
            x=zf_symb;
            no_iter=0;
        else
            %the zf solution is not feasible. solve the box problem.
            [x,tmp,no_iter]=br_solver(y,R,u,istate,1);
        end;
        lambda=(Hy-HH*x)./x;
        lambda(lambda<0)=0;