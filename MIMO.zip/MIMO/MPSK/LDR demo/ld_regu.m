function [s_hat] = ld_regu(y,H,T,u,radius)
%   Regularized lattice decoding
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
% Exact solver for the problem
% min ||y -H s_hat||_2^2 + s_hat^T T s_hat
% s.t.  -u<=[s_hat]_i<=u, [s_hat]_i is an odd integer
%            for i=1,...,N.  
%
% usage : [s_hat] = ld_regu(y,H,T,u); or
%         [s_hat] = ld_regu(y,H,T,u, radius); or
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- T - positive semi-definite regularization matrix of dimension N by N
% -- u - symbol bound that is a positive odd integer.
% -- radius - radius parameter of the sphere decoding algorithm;
%             unspecified or a positive number.
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

%number of tx symbols
N=size(H,2);

%triangularize the channel
R=chol(H'*H+T);
y=R'\(H'*y);
s_hat=dfc_u(y,R,u);



end

