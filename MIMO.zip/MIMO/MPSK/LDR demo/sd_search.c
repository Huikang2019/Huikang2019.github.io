/*
sphere decoding (Schnorr�CEuchner enumeration ) algorithm

developed by
       Jiaxian Pan and Wing-kin Ma 
       {jxpan@ee.cuhk.edu.hk, wkma@ieee.org}
       Department of Electronic Enginneering
       The Chinese University of Hong Kong,
       Shatin, N.T., Hong Kong

Summary:    Solving the problem min  ||y - R x||_2
 *                              s.t. ||y-Rx||_2 \leq radius  
 *                                   x_i is integer
 *                                   lb<=x_i<=ub, for all i
 * 
How to use:
           [x,info]=sd_search(y, H, radius, lb, ub)
 *
Input:  y: a vector of dimention N
 *      R: a full-rank upper triangular matrix of dimension N by N
 *      lb: an integer
 *      ub: an integer, must be greater than lb
        radius: a positive number and can be +inf,
        
Output: x is the optimal solution if info=1, and is undefined if info=0.
        info is an indicator: 1 if optimal solutio is found 
                                 (or equivalently the problem is feasible)
                              0 if the problem is infeasible
         
Statement:
This algorithm may be used freely for non-commercial purposes, and may be
freely distributed for non-commercial purposes.  


Based on the pseudo code (alg.II) in in
M. Damen, H. El Gamal, and G. Caire, ��On maximum-likelihood
detection and the search for the closest lattice point,�� IEEE Trans. Inf.
Theory, vol. 49, no. 10, pp. 2389�C2402, Oct. 2003.

*/


#include "mex.h" 
#include "math.h"

#include <string.h>
#define symb plhs[0]
#define info plhs[1]



double sign(double in)
{
    if (in <=0)
        return -1;
    else
        return 1;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
    double *y,*R,radius,lb,ub;
    double *t,*s,*delta,*x;
    double *symb_pr,*info_pr;
    mwSignedIndex i,j,M,N;
    
    if((nrhs!=5)|| (nlhs!=2))
        mexErrMsgTxt("USAGE: [symb,info]=sd_search(y,R,radius,lb,ub)\n"); 
    /*input*/
    y=mxGetPr(prhs[0]);
    R=mxGetPr(prhs[1]);
    radius=*mxGetPr(prhs[2]);
    lb=*mxGetPr(prhs[3]);
    ub=*mxGetPr(prhs[4]);
    
    /*dimention of R*/
    M=mxGetM(prhs[1]);
    N=mxGetN(prhs[1]);
    
    if (M!=N)
        mexErrMsgTxt("R must be square\n");
    
    /*t store the cumulative metric*/
    t=(double *)mxCalloc(N,sizeof(double));
    /*s helps computing t*/
    s=(double *)mxCalloc(N,sizeof(double));
    
    /*delta sotres the SE enumeration direction*/
    delta=(double *)mxCalloc(N,sizeof(double));
    
    /*x the solution*/
    x=(double *)mxCalloc(N,sizeof(double));
    
    /*output*/
    symb= mxCreateDoubleMatrix(N,1,mxREAL);
    info= mxCreateDoubleMatrix(1,1,mxREAL);
    
    symb_pr=mxGetPr(symb);
    info_pr=mxGetPr(info);
    *info_pr=-1;
    
    /*enumerate at the highest level*/
    i=N-1;
    
    /*set the SE enumeration center and direction*/
    x[i]=floor((y[i]-s[i])/R[N*N-1]+0.5);
    delta[i]=sign(y[i]-s[i]-R[N*N-1]*x[i]);
    
    /*main loop*/
    while(true)
    {
        if (radius<t[i]+pow(y[i]-s[i]-R[(i)*N+i]*x[i],2))
        {            
            /*step 4, outside the radius*/
            if (i==N-1)
                /*at the highest level, die*/
                break;
            else
            {
                /*go up one level, and do SE enumeration*/
                i++;
                x[i]=x[i]+delta[i];
                delta[i]=-delta[i]-sign(delta[i]);
                continue;             
            }
                                
        }
        else if ((x[i]<lb )|| (x[i]>ub))
        {
            /*step 6, outside of symbol bound, do SE enumeration*/
            x[i]=x[i]+delta[i];
            delta[i]=-delta[i]-sign(delta[i]);
            continue;
        }
        else if (i>0)
        {
            /*inside the radius and the symbol bounds, and not at the lowest level */
            /*calculate the metric of the current level and go down*/
            for(s[i-1]=0,j=i;j<N;j++)
                    s[i-1]=s[i-1]+R[j*N+i-1]*x[j];
            t[i-1]=t[i]+pow(y[i]-s[i]-R[i*N+i]*x[i],2);
            i--;
            
            /*step2, set the SE enumration center and direction*/
            x[i]=floor((y[i]-s[i])/R[i*N+i]+0.5);
            delta[i]=sign(y[i]-s[i]-R[i*N+i]*x[i]);
            continue;
        }
        else
        {
            /*step 5, a better feasible solution is found*/
            
            /*update the radius*/
            radius=t[0]+pow(y[0]-s[0]-R[0]*x[0],2);
            
            /*go up one level*/
            i++;
            /*save the solution*/
            memcpy(symb_pr,x,N*sizeof(double));
            /*we found a solution*/
            *info_pr=1;
            
            /*step 6, SE enumeration*/
            x[i]=x[i]+delta[i];
            delta[i]=-delta[i]-sign(delta[i]);
            continue;
        }        
    }
    
    
    mxFree(t);
    mxFree(s);
    mxFree(delta);
    mxFree(x);
    return;    
} 
