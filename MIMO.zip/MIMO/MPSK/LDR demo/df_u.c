/*
Decision feedback algorithm for approximating problem
  min ||y -R *s_hat||_2
     s.t.  -u<=[s_hat]_i<=u, [s_hat]_i is an odd integer
           for i=1,...,N.  
          
developed by
       Jiaxian Pan and Wing-kin Ma 
       {jxpan@ee.cuhk.edu.hk, wkma@ieee.org}
       Department of Electronic Enginneering
       The Chinese University of Hong Kong,
       Shatin, N.T., Hong Kong

Summary:  [s_hat]=df_u(y,R,u)

Input:  y is a real vector of dimension N
        R is a N by N upper triangular real matrix
        u is a possitive odd integer
 
Output: s_hat is the decision vector
       
         
Statement:
This algorithm can be freely distributed for academic or personal use. 
Please contact the authors if you intend to employ this function for 
commercial purpose. 

*/




#include "mex.h" 
#include "math.h"
#include <string.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
    double *y,*R,*s_hat,temp;
    int i,j,u;
    mwSize N,M;
    
    if((nrhs!=3)|| (nlhs!=1))
        mexErrMsgTxt("USAGE: [s]=df_u(y,R,u)\n"); 
    
    /*rx signal*/
    y=mxGetPr(prhs[0]);
    
    /*upper-triangularize channel*/
    R=mxGetPr(prhs[1]);
    
    /*symbol bound*/
    u=*mxGetPr(prhs[2]);
    
    /*allocate memory for output s_hat*/
    N=mxGetN(prhs[1]);
    M=mxGetM(prhs[1]);    
    if (M!=N)
        mexErrMsgTxt("R must be square\n");
    
    plhs[0]=mxCreateDoubleMatrix(N,1,mxREAL);
    s_hat=mxGetPr(plhs[0]);
    
    /*quantize s_hat[N-1] to odd integers*/
    s_hat[N-1]=2*floor(y[N-1]/R[N*N-1]/2+1)-1;
    /*apply symbol bound*/
    if (s_hat[N-1]>u)
        s_hat[N-1]=u;
    else if (s_hat[N-1]<-u)
        s_hat[N-1]=-u;
    
    
    for(i=N-2;i>=0;i--)
    {
        /*compute the effect of detected symbols from s_hat[N-1] to s_hat[i+1]*/
        temp=0;
        for(j=i+1;j<=N-1;j++)
        {
            temp=temp+s_hat[j]*R[j*N+i];
        }
        /*quantize s_hat[i] to odd integers*/
        s_hat[i]=2*floor((y[i]-temp)/R[i*N+i]/2+1)-1;
        /*apply symbol bound*/
        if (s_hat[i]>u)
            s_hat[i]=u;
        else if (s_hat[i]<-u)
            s_hat[i]=-u;
        
    }
    return;    
} 
