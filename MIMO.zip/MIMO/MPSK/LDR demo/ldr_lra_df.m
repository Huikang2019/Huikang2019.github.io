function [s,time] = ldr_lra_df(y,H,u,no_of_iter)
%   Lagrangian dual relaxation lattice reduction aided decision feed back (LDR LRA DF) detector
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
%   Approximate projected subgradient method for the problem
%   max d(lambda)
%   s.t. lambda>=0,
%   where lambda is of dimension N, and d(lambda) is defined as
%   d(lambda) = min ||y - H s||_2^2 + s^T D(lambda) s
%               s.t. s_i is an odd integer for i=1,...,N
%
% usage : [s_hat] = ldr_ld(y,H,u,no_of_iter); or
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- u - symbol bound that is a positive odd integer.
% -- no_of_iter - number of maximum PS iterations
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

tic
%parameter for choosing step size. Higher QAM size, smaller gamma.
if u==1
    gamma=0.05;
elseif u==3
    gamma=0.01;
elseif u==7
    gamma=0.002;
else
    gamma=0.0004;
end;


m=size(H,2);

%---------Box relaxation initilization----------------
%solve the problem via active set method
%             min ||y - H s||^2
%             s.t. -u <= s_i <= u, for all i

lambda=box_relaxation(y,H,u);
% lambda=zeros(m,1);

%-----------------------------------------------------


obj_best=inf;
s=zeros(m,1);

%precompute some matrixs that will be used many times later
HH=H'*H;Hy=H'*y;
Hy_HH1=Hy-sum(HH,2);
U=eye(m);

for k=1:no_of_iter
    %----LRA DF approximation to min_{s^n \in 2Z^n +1} \|y-Hs\|^2+ s^T D(lambda) s---
 
    if k==1
        W=chol(HH+diag(lambda));
    else
        W=chol(U'*(HH+diag(lambda))*U);
    end;
    f=(W'\(U'*(Hy_HH1-lambda)))/2;
    [Q,R,U_tilde]=lll(eye(m),W,3/4);
    U=U*U_tilde;
    f_tilde=Q'*f;
    z_tilde=df(f_tilde,R);

    %-----------choose the best candidate s------------
    %restore a primal feasible solution
    s_star=2*(U*z_tilde)+1;
    s_temp=min(max(s_star,-u),u);
    
    %check the objective value, and keep it if it is the best one
    obj_current=norm(y-H*s_temp);
    if (obj_current<=obj_best)
        obj_best=obj_current;
        s=s_temp;
    end;
    
    %------------------------------------------------
    %approximate subgradient
    subgrad=s_star.^2-u*u;
    
    %stepsize
    steps=gamma/sqrt(k); 
   
    %update lambda
    lambda_old=lambda;
    lambda=lambda+steps*subgrad;
    lambda=max(lambda,0);
    
    %if only marginal changes in lambda occur, exit
    if (norm(lambda_old-lambda)<=1e-9)
         break;
     end;
end
time=toc;