% Run this script to compile the c files

% Tested on
% 64bit windows 8 + matlab 2011b 64bit + Microsoft Visual C++ 2010 compiler
% 32bit window xp + matlab 2010b 32bit + Microsoft Visual C++ 2010 compiler
% 64bit CentOS Linux 5.5 + matlab 2012b 64bit + gcc 4.1.2
% 64bit CentOS Linux 6.0 + matlab 2011a 64bit + gcc 4.4.4


display('compiling...');

mex lll.c -largeArrayDims
mex br_bounding_info.c -largeArrayDims
mex df.c -largeArrayDims
mex df_u.c -largeArrayDims
mex sd_search.c -largeArrayDims


if ispc
    mex br_solver.c -largeArrayDims -L libmwblas.lib libmwlapack.lib;
elseif isunix
    mex br_solver.c -largeArrayDims -lmwblas -lmwlapack;
elseif ismac
    error('I don''t know how to compile in Mac. You need to figure it out by yourself. ');
end;

display('done.');