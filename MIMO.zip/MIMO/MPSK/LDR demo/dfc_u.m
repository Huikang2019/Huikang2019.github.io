function [ s ] = dfc_u( y,R,u )

[m,n]=size(R);
s=zeros(n,1);
s(n)=y(n)/R(n,n);
sk=round(u*angle(s(n))/(2*pi));
s(n)=exp(1i*sk*2*pi/u);
for i=2:n
    s(n+1-i)=(y(n+1-i)-R(n+1-i,n+2-i:n)*s(n+2-i:n))/R(n+1-i,n+1-i);
    sk=round(u*angle(s(n+1-i))/(2*pi));
    s(n+1-i)=exp(1i*sk*2*pi/u);
end
end
