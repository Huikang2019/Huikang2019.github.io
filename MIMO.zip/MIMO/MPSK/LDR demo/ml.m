function [w] = ml(y,H,u,rho)

[m,n] = size(H);
wk=(H'*H+rho^2*eye(n))\(H'*y);
zk=round(angle(wk)*u./(2*pi));
w = exp((1i*2*pi.*zk)./u);