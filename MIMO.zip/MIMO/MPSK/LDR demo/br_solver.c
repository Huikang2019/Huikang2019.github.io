/* Box relaxation solver
 *
 * developed by
 *      Jiaxian Pan and Wing-kin Ma 
 *      {jxpan@ee.cuhk.edu.hk, wkma@ieee.org}
 *      Department of Electronic Enginneering
 *      The Chinese University of Hong Kong,
 *      Shatin, N.T., Hong Kong
 * 
 *  Solve the following problem via the active set method
 *                  min || y - H x ||_2
 *                  s.t.   -u <= x_i <=u, i =1,...m.
 *
 *
 *  How to use
 *           [x, istate,no_iter,info]   =br_solver(y,H,u,istate,key)
 *
 *  Input parameter:
 *          y: a vector of dimension n
 *          H: an upper triangular matrix of dimension n by n
 *          u: scalar, positive
 *          istate: initialization if key =1, not refered if key=0
 *          key: use the initlization provided in istate if key=1,
 *               use an internal simple initialization if key=0 
 *           
 *  Output parameter:
 *          x: solution
 *          istate: bounding info. of x
 *          no_iter.: no of iterations
 *          info: 1: a solution is obtained
 *                0: no solution is obtained
 *
 *  Explaination on the bounding info. istate:
 *          istate is of dimenstion n+2,
 *          istate[0] is not refered
 *          istate[n+1] is the number of bounding variables
 *          for i=1 ... istate[n+1]
 *          if istate[i]< 0 then
 *             x[abs(istate[i])-1] is -u
 *          if istate[i]>0 then
 *             x[abs(istate[i])-1] is u.
 *          for i= istate[n+1]+1,...,n
 *             istate[i]>0 and  x[istate[i]-1] is a free variable 
 *
 *
 *  This code is largely based on the Bounded Variable Least Squares (BVLS) Fortran code
 *  originally developed by Robert L. Parker and Philip B. Stark.
 *
 *  We translate most of the Fortran code to C code in a word-to-word manner.
 *  We also made several modifications:
 *
 *  1.Perhaps the most signifcant change is the one column updating method 
 *    used in computing the lease square problems. The one column updating 
 *    method is adopted from M. Emtiyaz, updating inverse of a matrix when 
 *    a column is added/removed.? This modification can accelerate the this 
 *    programe in our experiment. But very likely, this also leads to 
 *    numberical instability and makes the added stability mechanism in the 
 *    original BVLS less effective. But numertical stability seems no problem
 *    in our experiment.
 *
 *  2.We make assumption that H is squared and the upper bound and lower bound
 *    are u an -u, respectively. This is only for our convenience.
 *
 *  3.We correct some small bugs which we think are really bugs.
 *
 *  We keep most of comments in the orginal source code. We also add our own
 *  comments in the hope of explaining things more clearly.
 *
 *  Statement:
 *  This algorithm may be used freely for non-commercial purposes, and may be 
 *  freely distributed for non-commercial purposes. 
 *  
 *  Reference:
 *  M. Emtiyaz, "Updating inverse of a matrix when a column is
 *  added/removed" [Online]. Available: http://www.cs.ubc.ca/~emtiyaz/
 *  Writings/OneColInv.pdf
 *
 *  P. Stark and R. Parker, "Bounded-variable least-squares: an algorithm
 *  and applications," Computational Statistics, pp. 129?41, 1995.
 *
 *
 *  Original Fortran BVLS source code:
 *  http://lib.stat.cmu.edu/general/bvls
*/
 
/*Statment from the original authors
c Summary:
c BVLS solves linear least-squares problems with upper and lower bounds on the
c variables, using an active set strategy.  It is documented in the J. of
c Computational Statistics, and can be used iteratively to solve minimum 
c l-1, l-2 and l-infinity fitting problems.  


c Statement:
c This algorithm may be used freely for non-commercial purposes, and may be
c freely distributed for non-commercial purposes.  The authors do not warrant
c the software in any way: use it at your own risk.
 *
c--------------------Bounded Variable Least Squares---------------------
c
c        Robert L. Parker and Philip B. Stark    Version 3/19/90
c
c  Robert L. Parker                           Philip B. Stark
c  Scripps Institution of Oceanography        Department of Statistics
c  University of California, San Diego        University of California
c  La Jolla CA 92093                          Berkeley CA 94720-3860
c  rlparker@ucsd.edu                          stark@stat.berkeley.edu
c
c  Copyright of this software is reserved by the authors; however, this 
c  algorithm and subroutine may be used freely for non-commercial 
c  purposes, and may be distributed freely for non-commercial purposes.  
c
c  The authors do not warrant this software in any way: use it at your 
c  own risk.
c
c
c  See the article ``Bounded Variable Least Squares:  An Algorithm and
c  Applications'' by P.B. Stark and R.L. Parker, in the journal 
c  Computational Statistics, in press (1995) for further description 
c  and applications to minimum l-1, l-2 and l-infinity fitting problems, 
c  as well as finding bounds on linear functionals subject to bounds on 
c  variables and fitting linear data within l-1, l-2 or l-infinity 
c  measures of misfit.
c
c  BVLS solves the problem: 
c
c          min  || a.x - b ||     such that   bl <= x <= bu
c                            2
c    where  
c               x  is an unknown n-vector
c               a  is a given m by n matrix
c               b  is a given  m-vector 
c               bl is a given n-vector of lower bounds on the
c                                components of x.
c               bu is a given n-vector of upper bounds on the
c                                components of x.
c
c               
c-----------------------------------------------------------------------
c    Input parameters:
c
c  m, n, a, b, bl, bu   see above.   Let mm=min(m,n).
c
c  If key = 0, the subroutine solves the problem from scratch.
c
c  If key > 0 the routine initializes using the user's guess about
c   which components of  x  are `active', i.e. are stricly within their
c   bounds, which are at their lower bounds, and which are at their 
c   upper bounds.  This information is supplied through the array  
c   istate.  istate(n+1) should contain the total number of components 
c   at their bounds (the `bound variables').  The absolute values of the
c   first nbound=istate(n+1) entries of  istate  are the indices
c   of these `bound' components of  x.  The sign of istate(j), j=1,...,
c   nbound, indicates whether  x(|istate(j)|) is at its upper or lower
c   bound.  istate(j) is positive if the component is at its upper
c   bound, negative if the component is at its lower bound.
c   istate(j), j=nbound+1,...,n  contain the indices of the components
c   of  x  that are active (i.e. are expected to lie strictly within 
c   their bounds).  When key > 0, the routine initially sets the active 
c   components to the averages of their upper and lower bounds: 
c   x(j)=(bl(j)+bu(j))/2, for j in the active set.  
c
c-----------------------------------------------------------------------
c    Output parameters:
c
c  x       the solution vector.
c
c  w(1)    the minimum 2-norm || a.x-b ||.
c
c  istate  vector indicating which components of  x  are active and 
c          which are at their bounds (see the previous paragraph).  
c          istate can be supplied to the routine to give it a good 
c          starting guess for the solution.
c
c  loopA   number of iterations taken in the main loop, Loop A.
c
c-----------------------------------------------------------------------
c    Working  arrays:
c
c  w      dimension n.               act      dimension m*(mm+2).
c  zz     dimension m.               istate   dimension n+1.
c
c-----------------------------------------------------------------------
c  Method: active variable method along the general plan of NNLS by
c  Lawson & Hanson, "Solving Least Squares Problems," 1974.  See
c  Algorithm 23.10.  Step numbers in comment statements refer to their 
c  scheme.
c  For more details and further uses, see the article 
c  "Bounded Variable Least Squares:  An Algorithm and Applications" 
c  by Stark and Parker in 1995 Computational Statistics.
c
c-----------------------------------------------------------------------
c  A number of measures are taken to enhance numerical reliability:
c
c 1. As noted by Lawson and Hanson, roundoff errors in the computation
c   of the gradient of the misfit may cause a component on the bounds
c   to appear to want to become active, yet when the component is added
c   to the active set, it moves away from the feasible region.  In this
c   case the component is not made active, the gradient of the misfit
c   with respect to a change in that component is set to zero, and the
c   program returns to the Kuhn-Tucker test.  Flag  ifrom5  is used in 
c   this test, which occurs at the end of Step 6.
c
c
c 2. When the least-squares minimizer after Step 6 is infeasible, it
c   is used in a convex interpolation with the previous solution to 
c   obtain a feasible vector.  The constant in this interpolation is
c   supposed to put at least one component of  x   on a bound. There can
c   be difficulties: 
c
c 2a. Sometimes, due to roundoff, no interpolated component ends up on 
c   a bound.  The code in Step 11 uses the flag  jj, computed in Step 8,
c   to ensure that at least the component that determined the 
c   interpolation constant  alpha  is moved to the appropriate bound.  
c   This guarantees that what Lawson and Hanson call `Loop B' is finite.
c
c 2b. The code in Step 11 also incorporates Lawson and Hanson's feature
c   that any components remaining infeasible at this stage (which must
c   be due to roundoff) are moved to their nearer bound.
c
c
c 3. If the columns of  a  passed to qr are linearly dependent, the new
c   potentially active component is not introduced: the gradient of the
c   misfit with respect to that component is set to zero, and control
c   returns to the Kuhn-Tucker test.
c
c
c 4. When some of the columns of  a  are approximately linearly 
c   dependent, we have observed cycling of active components: a 
c   component just moved to a bound desires immediately to become 
c   active again; qr allows it to become active and a different 
c   component is moved to its bound.   This component immediately wants
c   to become active, which qr allows, and the original component is
c   moved back to its bound.  We have taken two steps to avoid this 
c   problem:
c
c 4a. First, the column of the matrix  a  corresponding to the new 
c   potentially active component is passed to qr as the last column of 
c   its matrix.  This ordering tends to make a component recently moved
c   to a bound fail the test mentioned in (1), above.
c
c 4b. Second, we have incorporated a test that prohibits short cycles.
c   If the most recent successful change to the active set was to move
c   the component x(jj) to a bound, x(jj) is not permitted to reenter 
c   the solution at this stage.  This test occurs just after checking
c   the Kuhn-Tucker conditions, and uses the flag  jj, set in Step 8.
c   The flag  jj  is reset after Step 6 if Step 6 was entered from
c   Step 5 indicating that a new component has successfully entered the
c   active set. The test for resetting  jj  uses the flag  ifrom5,
c   which will not equal zero in case Step 6 was entered from Step 5.
c
 *
*/




#include "memory.h"
#include <math.h>
#include "mex.h"
#include "blas.h"
#include "lapack.h"


double sign(double x);
double qr_sls(mwSignedIndex m, mwSignedIndex n, mwSignedIndex nact, double *H, double * HH_inv, double *y, double *x, double *work);
void update_inverse(mwSignedIndex m, mwSignedIndex n, mwSignedIndex nact, double *H, double *HH_inv, double* v, double * work, mwSignedIndex ind);


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /*input data*/
    double *y,*H; 
    mwSignedIndex *istate;  /*provide initial bounding info.*/
    mwSignedIndex key;      /*if key==1, the info in istate is used as initialization*/
    double u,un;
    /*----------*/
    
    double *x, *istate_out,*no_iter,*istate_in,*residue,*v; /*working var.*/
    double *w, *act,*zz;                         /*working var.*/
    double alpha,alf,obj,bound,resq,sj;  
    mwSignedIndex m,n,mm,mm1,mn,nbound,nact,noldb;
    mwSignedIndex i,j,jj,ifrom5,k,ks,k1,it,loopA,iact=1;
    double *info;
    double bnorm,bad,worst,temp;
    
    const double eps=1e-11;
    
    /*variables for callling lapack least square*/
    double *work;                    /*for tempory use and calling subfunctions*/
    mwSignedIndex one=1;
    double minusone=-1.0;
    double plusone=1.0;
    char  NOtran='N';
    char  Tran='T';
    char Upper='U';
    char Diag='N';
    double zero=0.0;
    /*-----------------------------------------*/
    
    /*for successive least square*/
    mwSignedIndex ind=0;        
    /* ind==0, compute a new inverse
                         ind<0, a new column is added to the last column of H
                         ind >1, the ind'th column of H is deleted*/
    
    double *HH_inv;     /* store the inverse of active H'*H*/
    
    
    /*------------------------------------*/
    y=mxGetPr(prhs[0]);     /*dimentsion n*/
    H=mxGetPr(prhs[1]);     /*dimentsion m by n */
    u=*mxGetPr(prhs[2]);   /*dimentsion n*/
    un=-u;
    istate_in=mxGetPr(prhs[3]);/*dimentsion n+2*/
    key=(mwSignedIndex)*mxGetPr(prhs[4]);          /*scalar*/
    
    /*dimension of H*/
    n=mxGetN(prhs[1]);
    m=mxGetM(prhs[1]);
    
    if (n!=m)
         mexErrMsgTxt("This function assumes n==m");
        
    
    plhs[0]=mxCreateDoubleMatrix(n,1,mxREAL);
    plhs[1]=mxCreateDoubleMatrix(n,1,mxREAL);
    plhs[2]=mxCreateDoubleMatrix(1,1,mxREAL);
    plhs[3]=mxCreateDoubleMatrix(1,1,mxREAL);
    
    /*no need to check whether the memory is successful,
     *the mex file will exit if unsuccessful.
    if (plhs[0]==NULL ||
        plhs[1]==NULL ||    
        plhs[2]==NULL ||
        plhs[3]==NULL)
     mexErrMsgTxt("Cannot allocate memory");
     */
    
    /*--------------output---------------*/
    
    /*solution*/
    x=mxGetPr(plhs[0]);
    
    /*bounding info. of the soltuion*/
    istate_out=mxGetPr(plhs[1]);
    
    /*no. of iteration used*/
    no_iter=mxGetPr(plhs[2]);
    
    /*indicatior of whether the problem is solved sucessfully*/
	info=mxGetPr(plhs[3]);
    /*initialize to successful*/
    *info=1;
    /*------------------------------------*/
    
    
    /*Step 1. c Initialize everything--active and bound sets, initial 
    c values, etc.
    c Initialize flags, etc.*/
    
    mm=m;
    mn=m*n;
    mm1=mm+1;
    jj=0;
    ifrom5=0;
    
    /*c Check consistency of given bounds  bl, bu.*/
    /*we don't need this part*/
    /*
     bdiff=0.0;
     for(i=0;i<n;i++)
     {
         bdiff=maxd(bdiff, bu[i]-bl[i]);
         if (bl[i]>bu[i])
             mexErrMsgTxt("Inconsistent bounds in BVLS");
     }    
     if (bdiff==0.0)
         mexErrMsgTxt("No free variables in BVLS-- check input bounds");
    */
     
  /*In a fresh initialization (key = 0) bind all variables at their lower
   bounds.  If (key != 0), use the supplied  istate  vector to
   initialize the variables.  istate(n+1) contains the number of
   bound variables.  The absolute values of the first 
   nbound=istate(n+1) entries of  istate  are the indices of the bound
   variables.  The sign of each entry determines whether the indicated
   variable is at its upper (positive) or lower (negative) bound. */   
    
    /*bounding info, for internal use*/
    istate=(mwSignedIndex *)mxCalloc(n+2,sizeof(mwSignedIndex));
    
    /*copy bounding info. to avoid modifying the input to this function*/
    for(i=0;i<=n+1;i++)
        istate[i]=(mwSignedIndex)istate_in[i];
    
    w=(double *)mxCalloc(n,sizeof(double));        
    act=(double *)mxCalloc(n*(m+2),sizeof(double));     /*store the columns of H corresponding to free variables*/
                                                        /*may be n*(min(m,n)+2); there may be a typo in the source code*/
    zz=(double *)mxCalloc(m,sizeof(double));
    work=(double *)mxCalloc(2*n, sizeof(double));
    HH_inv=(double *)mxCalloc(n*n,sizeof(double));      /*the pseudo-inverse of the active columns of H*/
    
    /*
    if (w==NULL ||
        act==NULL ||
        zz==NULL ||
        work==NULL ||
        HH_inv ==NULL)
        mexErrMsgTxt("Cannot allocate memory");
    */
    
    residue=act+(mm1-1)*m;
    
    if (key==0)
    {
        /*initialize the solution to the lower bound*/
        nbound=n;   /*number of bounded variables*/
        nact=0;     /*number of free variables*/
        
        /*set the bounding info. of this solution*/
        for(j=1;j<=nbound;j++)
        {
            istate[j]=-j;
        }
    }
    else
    {
        /*use the initial point provided by the input*/
        nbound=istate[n+1];
        nact=n-nbound;
        
        /*check if there are too many free variables*/
        if (nact > mm)
        {
            mxFree(w);
            mxFree(istate);
            mxFree(zz);
            mxFree(act);
            mxFree(work);
            mxFree(HH_inv);
            mexErrMsgTxt("Too many active variables in BVLS starting solution!");
        }
        
        /*setup initialize solution x according to the bounding info*/
        /*set the bounding variable to the corresponding upper or lower bound*/
        for(k=1;k<=nbound;k++)
        {
            j=abs(istate[k]);
            if (istate[k] <0 ) 
            {
                x[j-1]=un;
            }
            if (istate[k]>0)
            {
                x[j-1]=u;
            }
        }
        /*set the free variable to zero*/
        for(k=nbound+1;k<=n;k++)
        {
            j=istate[k];
            x[j-1]=0;
        }
    }
    


    
/*  Compute bnorm, the norm of the data vector b, for reference.*/    
   
    bnorm=dnrm2(&m, y, &one);  /*check whether y is changed by dnrm2*/
    
    
    /*copy to act the columns of H corresponding to free variables*/
    for(k=nbound+1;k<=n;k++)
    {
          j=istate[k];
          memcpy(act+(n-k)*m,H+(j-1)*m,m*sizeof(double));
    }
    
    /*compute the pseudo-inverse of the active columns*/
    update_inverse(m,n,nact,act,HH_inv,v,work,0);
    
/*-------------------main loop------------------------*/
/*c  Initialization complete.  Begin major loop (Loop A).*/
    for(loopA=1;loopA<=3*n;loopA++)
      {
        /*  Step 2. Compute the residual vector y-H x , the negative gradient vector
           w=H'*(y-Hx), and the current objective value obj = ||y-Hx||.
           The residual vector is stored in the mm+1'st column of act(*,*).*/
        
          /*Upper triangular H is assumed*/
         /* work <-- H*x, just for calculating y-H*x */
          memcpy(work, x, n*sizeof(double));
          dtrmv(&Upper, &NOtran, &Diag, &n, H, &m, work, &one);
          
          
          /* residue <-- y-H*x*/
          memcpy(residue, y, m*sizeof(double));
          daxpy(&m, &minusone, work, &one, residue, &one);
               
          /* obj <--  ||y-H*x|| */
          obj=dnrm2(&m,residue,&one);      
          obj=obj*obj;
          
          /*  w <- H'*(y-H*x) */
          memcpy(w, residue, m*sizeof(double));
          dtrmv(&Upper, &Tran,&Diag, &m, H, &m, w, &one);
          
          
          /*c
         c  Check convergence. Stop if the residual is small enough, or if all components are 
        c   active (unless this is the first iteration from a warm start).*/          
          if ((sqrt(obj) < bnorm*eps) || (loopA > 1) && (nbound == 0))
          {                       
              istate[n+1]=nbound;
              w[0]=sqrt(obj);
              *no_iter=loopA;
			  mxFree(w);
              mxFree(istate);
              mxFree(zz);
              mxFree(act);
              mxFree(work);
              mxFree(HH_inv);
              return;
            }
          
          /*add the contribution of the active components back into the residual*/
          for(k=nbound+1;k<=n;k++)
          {
              j=istate[k];
              
              /*add the x[j-1]'s contribution*/
              /*residue<- residue+ H(:,j-1)* x(j-1) */
              daxpy(&m, x+j-1, H+(j-1)*m, &one,residue,&one);
          }
          
          
            /*c  The first iteration in a warm start requires immediate qr.*/          
          if ((loopA ==1) && (key !=0))
                goto l6000;
                           
            /*  Steps 3, 4.
          c  Find the bound element that most wants to be active.*/
          l3000:    worst=0.0;
          it=1;
          for(j=1;j<=nbound;j++)
          {
              ks=abs(istate[j]);
              bad=w[ks-1]*sign(istate[j]);
              if (bad < worst)
              {
                  worst=bad;
                  it=j;         /*istat[it] wants to be active most*/
                  iact=ks;      /*iact wants to be active most*/
              }
          }
          
          if (worst>=0.0)
          {
              /*no one can wants to move, KKT condition satisfied, optimal solution found*/
              istate[n+1]=nbound;
              w[0]=sqrt(obj);
              *no_iter=loopA;
              mxFree(w);
              mxFree(istate);
              mxFree(zz);
              mxFree(act);
              mxFree(work);
              mxFree(HH_inv);
              return;
          }
          
          /*c  The component  x(iact)  is the one that most wants to become active.
            c   If the last successful change in the active set was to move x(iact)
            c   to a bound, don't let x(iact) in now: set the derivative of the 
            c   misfit with respect to x(iact) to zero and return to the Kuhn-Tucker
            c   test.  */
          
          if (iact == jj)
          {
              w[jj-1]=0.0;
              goto l3000;
          }
          
          /*  Step 5. set x[iact-1] free 
           *  Undo the effect of the new (potentially) active variable on the 
           *   residual vector.*/
          if (istate[it] > 0) bound=u;
          if (istate[it] < 0) bound=un;
          
          /*remove the effect of x[iact-1] to residue*/
          daxpy(&m, &bound, H+(iact-1)*m,&one,residue,&one);

  
            /*c  Set flag ifrom5, indicating that Step 6 was entered from Step 5.
            c   This forms the basis of a test for instability: the gradient
            c   calculation shows that x(iact) wants to join the active set; if 
            c   qr puts x(iact) beyond the bound from which it came, the gradient 
            c   calculation was in error and the variable should not have been 
            c   introduced.*/
          
          ifrom5=istate[it];
          
            /*c  Swap the indices (in istate) of the new active variable and the
            c   rightmost bound variable; `unbind' that location by decrementing
            c   nbound.*/
          
          istate[it]=istate[nbound];
          nbound=nbound-1;
          
          /*one column is appended to the last column of act,
           update HH_inv and act*/
          
          v=act+nact*m;
          memcpy(v, H+(iact-1)*m, m*sizeof(double));
          update_inverse(m,n,nact,act,HH_inv,v,work,-1);
          
          
          nact=nact+1;
          istate[nbound+1]=iact;
          
          if( mm < nact)
          {
            mxFree(w);
            mxFree(istate);
            mxFree(zz);
            mxFree(act);
            mxFree(work);
            mxFree(HH_inv);
            mexErrMsgTxt("Too many free variables!");
          }

            /*  Step 6.
            c  Load array  act  with the appropriate columns of  H  for qr.  For
            c   added stability, reverse the column ordering so that the most
            c   recent addition to the active set is in the last column.  Also 
            c   copy the residual vector from act(., mm1) into act(., mm1+1).*/
          
           /*As we use one column update in computing the inverse of active H'H, 
            * we won't load active columns in reverse order.*/
          /*compute ||residue - H x||
           *where x and H are the free variables and the corresponding columns
           */
l6000:	  memcpy(act+mm1*m,residue,m*sizeof(double));
		  resq=qr_sls(m, n, nact, act, HH_inv, act+mm1*m, zz, work);

          
          
            /*  Test for linear dependence in qr, and for an instability that moves
            c   the variable just introduced away from the feasible region 
            c   (rather than into the region or all the way through it). 
            c   In either case, remove the latest vector introduced from the
            c   active set and adjust the residual vector accordingly.  
            c   Set the gradient component (w(iact)) to zero and return to 
            c   the Kuhn-Tucker test.          */
          
          if ((resq <0) || (ifrom5 > 0 && zz[nact-1] > u) || (ifrom5 <0 && zz[nact-1] < un))
          {
              nbound++;

              istate[nbound]=istate[nbound]*((x[iact-1]-u>0.0)?1:-1);
              
              /*the last column of act is removed, update HH_inv*/
              update_inverse(m,n,nact,act,HH_inv,v,work,nact);
              
              nact=nact-1;
              
              temp=-x[iact-1];
              
              daxpy(&m, &temp, H+(iact-1)*m,&one,residue,&one);

              ifrom5=0;
              w[iact-1]=0.0;
              goto l3000;
          }

        /*  If Step 6 was entered from Step 5 and we are here, a new variable 
        c   has been successfully introduced into the active set; the last 
        c   variable that was fixed at a bound is again permitted to become 
        c   active.*/
          
          if (ifrom5 !=0) jj=0;
          ifrom5=0;
          
        /*  Step 7.  Check for strict feasibility of the new qr solution.*/          

          for(k=1;k<=nact;k++)
          {
              k1=k;
              j=istate[k+nbound];
              /*if infeasible, go to 18000*/
              if( (zz[nact-k] < un) || (zz[nact-k]> u))
                  goto l8000;
          }
          /*the new qr solution is feasible, copy it to x*/
          for(k=1;k<=nact;k++)
          {
              j=istate[k+nbound];
              x[j-1]=zz[nact-k];
          }
          /*   back to the top.*/
          continue;         
      
       /* Steps8,9*/
      /*find the largest stepsize alp so that x + alp*(zz-x) is within bound
       *here x and zz refer to the free variable
       *alpha is also constrained to be less than 2.0*/    
      l8000: alpha=2.0;
      alf=alpha;
      for(k=k1;k<=nact;k++)
      {
          j=istate[k+nbound];
          /*compute the largest stepsize for x[j-1]*/
          if (zz[nact-k] > u)
              alf=(u-x[j-1])/(zz[nact-k]-x[j-1]);
          if (zz[nact-k] < un)
              alf=(un-x[j-1])/(zz[nact-k]-x[j-1]);
          /*find the smallest stepsize among all x[j-1]*/
          if (alf < alpha)
          {
              alpha=alf;
              jj=j;   /*x[jj-1] is the one that has active bounding constraint*/
              /*written as sj=sign(zz[nact-k]-un) in the original BVLS, but this should be better
               *sj=1 indicates that zz[nact-k] should be bounded to u
               *sj=-1 indicates that zz[nact-k] should be bounded to -u
               */
              sj=sign(zz[nact-k]);
              
          }
      }
      
      /*Step10*/      
      /*walk to x+alp*(zz-x)*/
      for(k=1;k<=nact;k++)
      {
          j=istate[k+nbound];
          x[j-1]=x[j-1]+alpha*(zz[nact-k]-x[j-1]);
      }
      
        /*c  Step 11.  
        c  Move the variable that determined alpha to the appropriate bound.  
        c   (jj is its index; sj is + if zz(jj)> bu(jj), - if zz(jj)<bl(jj) ).
        c   If any other component of  x  is infeasible at this stage, it must
        c   be due to roundoff.  Bind every infeasible component and every
        c   component at a bound to the appropriate bound.  Correct the
        c   residual vector for any variables moved to bounds.  Since at least
        c   one variable is removed from the active set in this step, Loop B 
        c   (Steps 6-11) terminates after at most  nact  steps.*/

      noldb=nbound;
      i=0;  /*remember how many free variables are fixed in the following loop*/
      for(k=1;k<=nact;k++)
      {
          j=istate[k+noldb];
          if ( (u-x[j-1])<=0.0 || ( (j ==jj) && (sj >=0.0)))
          {              
              /*x[j-1] is greater than u */
              /*move x[j-1] to the upper bound bound*/
              /*residue<- residue- H(:,j-1)*u */
              daxpy(&m, &un, H+(j-1)*m,&one,residue,&one);
              x[j-1]=u;
              
              /*update istate*/
              memmove(istate+nbound+2,istate+nbound+1, (k+noldb-nbound-1)*sizeof(mwSignedIndex));
              nbound++;
              istate[nbound]=j;
       
              /*the nact-k+1+i th column of act is removed, update the inverse*/
              memmove(act+(nact-k+i)*m, act+(nact-k+i+1)*m,(k-i-1)*m*sizeof(double));
              update_inverse(m,n,nact,act,HH_inv,v,work,nact-k+i+1);
              
              nact--;
              i++;
          }
          else if ((x[j-1]-un<=0.0 ) || ( j==jj && sj < 0.0))
          /*move x[j-1] to its lower bound*/
          {
              /*x[j-1] is smaller than -u*/
              /*move x[j-1] to the lower bound bound*/
              /*residue<- residue- H(:,j-1)*u */
              daxpy(&m, &u, H+(j-1)*m,&one,residue,&one);
              x[j-1]=un;
              
              /*update istate*/
              memmove(istate+nbound+2,istate+nbound+1, (k+noldb-nbound-1)*sizeof(mwSignedIndex));
              nbound++;
              istate[nbound]=-j;

             
              
              /*the nact-k+1+i th column of act is removed, update the inverse*/
              memmove(act+(nact-k+i)*m, act+(nact-k+i+1)*m,(k-i-1)*m*sizeof(double));
              update_inverse(m,n,nact,act,HH_inv,v,work,nact-k+i+1);
              
              nact--;
              i++;
          }
      }
          

        /*  If there are still active variables left repeat the qr; if not,
        c    go back to the top.*/
      if (nact >0) goto l6000;
          
    }
          
      *info=-1;       
      mxFree(w);
      mxFree(istate);
      mxFree(zz);
      mxFree(act);
      mxFree(work);
      mxFree(HH_inv);
      return;
      
}



double sign(double x)
{
    if(x>=0)
        return 1.0;
    else
        return -1.0;
}


double qr_sls(mwSignedIndex m, mwSignedIndex n, mwSignedIndex nact, double *H, double * HH_inv, double *y, double *x, double *work)
{
    /*Solve the problem of min ||y - H x||
     *given y, H,and the inverse of H'*H
     *the output is through the pointer x, and the function value as the objective value*/
    
    double resq;    /*objective value*/
    
    /*some constant for calling lapack and blas*/
    char NOtran= 'N';
    char Tran='T';
    char Upper='U';
    mwSignedIndex one=1;
    double plusone=1.0;
    double minusone=-1.0;
    double zero=0.0;
    
    
    /*  work<-- H'*y  */
    dgemv(&Tran, &m,&nact, &plusone, H, &m, y, &one, &zero, work, &one);
    
    /* x <-- HH_inv * work*/
    dsymv(&Upper, &nact, &plusone, HH_inv, &n, work,&one, &zero, x,&one);
    
    /* y <-- y-H*x   */
    dgemv(&NOtran, &m,&n,&minusone, H, &m, x,&one, &plusone, y, &one);
    
    /* resq= ||y||^2*/
    resq=dnrm2(&m, y, &one);
    resq=resq*resq;
    
    return resq;
}


void update_inverse(mwSignedIndex m, mwSignedIndex n, mwSignedIndex nact, double *H, double *HH_inv, double* v, double * work, mwSignedIndex ind)
{
    
    mwSignedIndex i,j,k;                       /*size of qr_work*/
    double d;
    double *u1, *u2; /*working data*/
    
    /*some constant for calling lapack and blas*/
    char NOtran= 'N';
    char Tran='T';
    char Upper='U';
    mwSignedIndex one=1;
    mwSignedIndex info;
    double plusone=1.0;
    double minusone=-1.0;
    double zero=0.0;
        
    if(m!=n)
       mexErrMsgTxt("m and n are not equal.");
    
    u1=work;
    u2=work+n;
    
      /* ind=0, compute the inverse
     * ind<0, a new column v is appended to the last column of H 
     * ind>0, the ind'th column of H is deleted*/
    

    
    /*calculate the updated HH_inv*/
    if (ind==0)
    {
        /*Calculate the upper triangular part of H'*H */
        for(i=0;i<nact;i++)
            for(j=0;j<=i;j++)
                *(HH_inv+i*n+j)=ddot(&m, H+i*m, &one, H+j*m,&one);
        
        /*calculate the Cholesky decompostion of H'*H first */
        dpotrf(&Upper, &nact, HH_inv, &n,&info);
        if (info!=0)
           mexErrMsgTxt("Cannot compute Chol decomposition of H'*H.");

        /* calculate a new HH_inv */
        dpotri(&Upper, &nact, HH_inv, &n, &info);
        if (info !=0)
           mexErrMsgTxt("Cannot compute the pseudoinverse.");
       /*fill the lower triangular part of HH_inv*/
        /*check whether this operation is needed or not*/
       
       /*for(i=0;i<nact-1;i++)
       {
            k=nact-i-1;
            dcopy(&k, HH_inv+(i+1)*n+i,&n, HH_inv +i+i*n+1, &one); 
       }*/
            
    }    
    else if (ind <0)
    {
        /*In all comments of this part, H actually means H(:,1:end-1)*/
        /* a new column v is appended to the last column of H*/
        /* nact is the column no of the original H */
                
        k=nact;
        /*u1 <-- H'*v  */
        dgemv(&Tran, &m, &k, &plusone, H, &m, v, &one, &zero, u1, &one);
        
        /* u2 <--HH_inv * u1*/
        dsymv(&Upper,&k, &plusone, HH_inv, &n, u1, &one, &zero,u2,&one);
        
        /*d <-- 1/(v'*v-u1'*u2) */
        d=1/(ddot(&m,v,&one,v,&one)-ddot(&k,u1,&one,u2,&one));
        
        /*Update HH_inv*/
        /*Top left part of HH_inv, HH_inv <--- HH_inv +d*u2*u2' */
        /*only the upper triangular part is updated*/
        dsyr(&Upper, &k, &d, u2, &one, HH_inv, &n);
        
        /* the last element */
        *(HH_inv+nact*n+nact)=d;
        
        /* Top right part of HH_inv */
        memcpy(HH_inv+k*n,u2,k*sizeof(double));
        d=-d;
        dscal(&k,&d, HH_inv+k*n,&one);
        
        /*Bottom left part, the same as top right part*/
        /*may not need*/
        /*xcopy(&k, HH_inv+(nact-1)*n,&one, HH_inv+nact-1, &n);*/
    }    
    else
    {
        /* nact is the column no. of the original H */
        
        k=nact;

        /*d=-1.0/ HH_inv(ind,ind)*/
        d=-1.0/HH_inv[(ind-1)*n+ind-1]; 
        
        /*move to u1 the ind'th column of HH_inv with HH_inv(ind,ind) removed*/
        /*be careful about the sysmmetric struct. of HH_inv */
        memcpy(u1,HH_inv+(ind-1)*n,(ind-1)*sizeof(double));
        j=nact-ind;
        dcopy(&j,HH_inv+ind*n+ind-1, &n,u1+ind-1,&one);
        
        /*delete the ind' column and row of HH_inv*/
        
        /*this part can be improved*/
        /*move the HH_inv(:, ind+1:nact) to HH_inv(:,ind:nact-1)*/
        memmove(HH_inv+(ind-1)*n,HH_inv+ind*n, n*(nact-ind)*sizeof(double));
        /*move HH_inv(ind+1: nact ,:) */
        for(i=ind-1;i<nact-1;i++)
            memmove(HH_inv+i*n+ind-1, HH_inv+i*n+ind,(i-ind+2)*sizeof(double));
        
        /*HH_inv <--- HH_inv +d*u2 *u2' */
        /*only the upper triangular part is updated*/
        nact=nact-1;
        dsyr(&Upper, &nact, &d, u1, &one, HH_inv, &n);   
    }
    return;
}