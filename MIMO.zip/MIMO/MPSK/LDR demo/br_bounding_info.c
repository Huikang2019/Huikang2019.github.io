/*Auxilary function for the active set method for solving the box relaxation problem.
 *
 *Input: 
 *          x: real vector dimention m
 *          u: bound
 *
 *Output:
 *          istate: real vector of dimention m+2, provding bounding info. of x.
 *
 *Summary:
 *          istate[0] is not refered
 *          istate[m+1] is the number of elements of x that are greater than u or less than -u
 *          istate[i] for i=1,...,istate[m+1] 
 *                    if istate[i]>0, then x[abs(istate[i])-1] >=u
 *                    if istate[i]<0, then x[abs(istate[i])-1] <=-u
 *          istate[i] for i=istate[m+1]+1,...,m 
 *                    istate[i]>0 and -u<=x[abs(istate[i])-1] <=u
 *          
 */


#include "memory.h"
#include <math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *x; /*input data*/
    double u,un;
    double *istate; /*output data*/
    mwSignedIndex i,j,k,m;
    
    x=mxGetPr(prhs[0]);     /*dimentsion m*/
    
    u=*mxGetPr(prhs[1]);          /*scalar*/
    un=-u;
    
    m=mxGetM(prhs[0]);

    plhs[0]=mxCreateDoubleMatrix(m+2,1,mxREAL);
    istate=mxGetPr(plhs[0]);
    
    j=1;
    k=m;
    for(i=1;i<=m;i++)
    {
        if (x[i-1]<=un)
        {
            istate[j]=-i;
            j++;
        }
        else if (x[i-1]>=u)
        {
            istate[j]=i;
            j++;
        }
        else
        {
            istate[k]=i;
            k--;
        }
        
    }
    istate[m+1]=j-1;    
}


