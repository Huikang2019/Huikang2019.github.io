function [ s_hat,iterk ] = GPM( y, H, u, rho, s,l )

[m,n] = size(H);

itermax=2*m;
Ss=(m+4*rho^2)^-1;
iterk=0;
w=zeros(n,itermax);
w(:,1) = s;


for k =1:itermax-1
    gradk=H'*(H*w(:,k)-y);
    wk=w(:,k)-l*Ss*gradk;
    zk=round(angle(wk)*u./(2*pi));
    s_hat = exp((1i*2*pi.*zk)./u);
    for i=1:k
        if s_hat==w(:,i)
            return;
        end
    end
    w(:,k+1)=s_hat;
    iterk=iterk+1;
    
end
