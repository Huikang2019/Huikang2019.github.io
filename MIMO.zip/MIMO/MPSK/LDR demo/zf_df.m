function [s_hat] = zf_df(y,H,u)
% zero-forcing decision feedback (ZF-DF) detector
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
% 
% usage : [s_hat] = zf_df(y,H,u);
% ========================================================================
%
% Input parameters :
% -- y - received signal vector $\mathbf{y}$ of dimensions M by 1, 
% -- H - real channel realization matrix $\mathbf{H}$ of dimension M by N.
% -- u - symbol bound
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

R=chol(H'*H);

s_hat=dfc_u(R'\(H'*y),R,u);


end

