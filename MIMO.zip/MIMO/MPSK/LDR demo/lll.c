/*
Lenstra-Lenstra-Lovasz (LLL) reduction algorithm

developed by
       Jiaxian Pan and Wing-kin Ma 
       {jxpan@ee.cuhk.edu.hk, wkma@ieee.org}
       Department of Electronic Enginneering
       The Chinese University of Hong Kong,
       Shatin, N.T., Hong Kong

Summary: Given an matrix QR in the form of its qr decomposition Q and R,
         find a unimodular, orthogonal, upper triangular matrix T, Qo, Ro such that
          Qo*Ro = Q*R *To,
         and Ro is LLL reduced.

Usage:    [Qo,Ro,Uo]=lll(Q,R,delta)
 
Input:  Q: an M by N orthogonal matrix, M>=N. 
        R: and N by N upper triangular matrix
        delta: a parameter controlling the quality of the reduction,
              generally 3/4 is used

Output: Qo: an M by N orthogonal matrix 
        Ro: and N by N upper triangular matrix
        Uo: and N by N the corresponding unimodular matrix
       
         
Statement:
This algorithm can be freely distributed for academic or personal use. 
Please contact the authors if you intend to employ this function for 
commercial purpose.


Based on the pseudo code provided in
D. Wubben, R. Bohnke, V. Kuhn, K.-D. Kammeyer, "Near-maximum-likelihood 
        detection of MIMO systems using MMSE-based lattice reduction," 
        in Proc. IEEE Int. Conf. Commun., vol. 2, Paris, France, Jun. 2004, pp. 798�C802.

The original development of LLL is  
A. K. Lenstra, H. W. Lenstra, and L. Lovasz, "Factoring polynomials
with rational coefficients," Mathematische Annalen, vol. 261, pp. 515�C 534, 1982.
*/


#include "mex.h" 
#include "math.h"
#include <string.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
    double *Qi,*Ri,delta;   /*input data*/
    double *Qo,*Ro,*Uo;     /*output data*/
    double a,b,u,t,*temp;   /*for tempory use*/
    mwSignedIndex k,l,i;
    mwSignedIndex M,N,t1,t2; /*problem size*/
    
    if((nrhs!=3)|| (nlhs!=3))
        mexErrMsgTxt("USAGE: [Qo,Ro,Uo]=lll(Q,R,delta)\n"); 
    
    Qi=mxGetPr(prhs[0]);
    Ri=mxGetPr(prhs[1]);
    M=mxGetM(prhs[0]);
    N=mxGetN(prhs[0]);
    t1=mxGetM(prhs[1]);
    t2=mxGetN(prhs[1]);
    
    if ((M<N) || (t1!=t2) || (t1!=N))
        mexErrMsgTxt("Check the size of input matrices\n");
    
    
    delta=*mxGetPr(prhs[2]);
    plhs[0]=mxCreateDoubleMatrix(M,N,mxREAL);
    plhs[1]=mxCreateDoubleMatrix(N,N,mxREAL);
    plhs[2]=mxCreateDoubleMatrix(N,N,mxREAL);
    Qo=mxGetPr(plhs[0]);
    Ro=mxGetPr(plhs[1]);
    Uo=mxGetPr(plhs[2]);    /*Uo has been initailized as zero matrix*/

    /*Copy the input to the output*/
    memcpy(Qo,Qi,M*N*sizeof(double));       
    memcpy(Ro,Ri,N*N*sizeof(double));
    
    /*for swapping data*/
    temp=(double *)mxCalloc(2*M,sizeof(double));
    
    /*initializ Uo to be identity matrix*/
    for (i=0;i<=N-1;i++)
        Uo[i*N+i]=1;
    
    k=2;    
    while(k<=N)
    {
        /*size reduction*/
        for(l=k-1;l>=1;l--)
        {
            /*u=round(Ro(l,k)/Ro(l,l))*/
            u=floor(Ro[(k-1)*N+l-1]/Ro[(l-1)*N+l-1]+0.5);
            /*check if u is nonzero*/
            if (u>=0.5 || u<=-0.5)
            {
                /*Ro(1:l,k)=Ro(1:l,k)-u*Ro(1:l,l)*/
                for(i=1;i<=l;i++)
                    Ro[(k-1)*N+i-1]=Ro[(k-1)*N+i-1]-u*Ro[(l-1)*N+i-1];
                /*Uo(:,k)=Uo(:,k)-u*Uo(:,l)*/
                for(i=1;i<=N;i++)
                    Uo[(k-1)*N+i-1]=Uo[(k-1)*N+i-1]-u*Uo[(l-1)*N+i-1];                              
            }
        }
        /*Check Lovasz condition
         *delta*Ro(k-1,k-1)^2> Ro(k,k)^2+Ro(k-1,k)^2
         */
        if (delta*Ro[(k-2)*N+k-2]*Ro[(k-2)*N+k-2]
            >Ro[(k-1)*N+k-1]*Ro[(k-1)*N+k-1]+Ro[(k-1)*N+k-2]*Ro[(k-1)*N+k-2])
        {
            /*swap the k-1 and k colum in Ro and Uo*/
            /*temp=Ro(:,k);Ro(:,k)=Ro(:,k-1);Ro(:,k-1)=temp;*/
            memcpy(temp,Ro+(k-1)*N,N*sizeof(double));
            memcpy(Ro+(k-1)*N,Ro+(k-2)*N,N*sizeof(double));
            memcpy(Ro+(k-2)*N,temp,N*sizeof(double));
            
            /*temp=Uo(:,k);Uo(:,k)=Uo(:,k-1);Uo(:,k-1)=temp*/
            memcpy(temp,Uo+(k-1)*N,N*sizeof(double));
            memcpy(Uo+(k-1)*N,Uo+(k-2)*N,N*sizeof(double));
            memcpy(Uo+(k-2)*N,temp,N*sizeof(double));
            
            
            
            /*t=||Ro(k-1:k,k-1)||*/
            t=sqrt(Ro[(k-2)*N+k-2]*Ro[(k-2)*N+k-2]+Ro[(k-2)*N+k-1]*Ro[(k-2)*N+k-1]);
            /*a=Ro(k-1,k-1)/t*/
            a=Ro[(k-2)*N+k-2]/t;
            /*b=Ro(k,k-1)/t*/
            b=Ro[(k-2)*N+k-1]/t;
            
            
            /*Ro(k-1:k,k-1:M)=theta*Ro(k-1:k,k-1:M);
             *where theta=[a b;-1*b a];
            */
            for(i=k-1;i<=N;i++)
            {
                temp[2*(i-k+1)]=a*Ro[(i-1)*N+k-2]+b*Ro[(i-1)*N+k-1];
                temp[2*(i-k+1)+1]=-b*Ro[(i-1)*N+k-2]+a*Ro[(i-1)*N+k-1];
            }

            for(i=k-1;i<=N;i++)
            {
                Ro[(i-1)*N+k-2]=temp[2*(i-k+1)];
                Ro[(i-1)*N+k-1]=temp[2*(i-k+1)+1];
            }

            
            /*Qo(:,k-1:k)=Qo(:,k-1:k)*theta'; 
             * where theta=[a b;-1*b a];
            */
            
            for(i=1;i<=M;i++)
            {
                temp[i-1]=a*Qo[(k-2)*M+i-1]+b*Qo[(k-1)*M+i-1];
                temp[M+i-1]=-b*Qo[(k-2)*M+i-1]+a*Qo[(k-1)*M+i-1];
            }
            memcpy(Qo+(k-2)*M,temp,2*M*sizeof(double));
            
            /*k=max(k-1,2)*/
            k=(k-1>2)?k-1:2;
        }
        else
            k++;     
    }        

    mxFree(temp);
    return;    
} 
