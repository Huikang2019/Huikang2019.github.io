/*
Decision feedback algorithm for approximating problem
  min ||y -R *s_hat||_2
     s.t. [s_hat]_i is an integer
           for i=1,...,N.  
          
developed by
       Jiaxian Pan and Wing-kin Ma 
       {jxpan@ee.cuhk.edu.hk, wkma@ieee.org}
       Department of Electronic Enginneering
       The Chinese University of Hong Kong,
       Shatin, N.T., Hong Kong

Summary:  [s_hat]=df(y,R)

Input:  y is a real vector of dimension N
        R is a N by N upper triangular real matrix
        
 
Output: s_hat is the decision vector
       
         
Statement:
This algorithm may be used freely for non-commercial purposes, and may be
freely distributed for non-commercial purposes. 

*/



#include "mex.h" 
#include "math.h"
#include <string.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
    double *y,*R,*x,temp;
    int i,j;
    mwSize M,N;
    
    if((nrhs!=2)|| (nlhs!=1))
        mexErrMsgTxt("USAGE: s=zf_df(y,R)\n"); 
    
    /*rx signal*/
    y=mxGetPr(prhs[0]);
    
    /*upper-triangle channel*/
    R=mxGetPr(prhs[1]);
    
    /*allocate memory for output x*/
    N=mxGetN(prhs[1]);
    M=mxGetM(prhs[1]); 
    
    if (M!=N)
        mexErrMsgTxt("R must be square\n");
    
    
    plhs[0]=mxCreateDoubleMatrix(N,1,mxREAL);
    x=mxGetPr(plhs[0]);
    
    /*quantize x[N-1] to integers*/
    x[N-1]=floor(y[N-1]/R[N*N-1]+0.5);
    
    
    for(i=N-2;i>=0;i--)
    {
        /*compute the effect of detected symbols from x[N-1] to x[i+1]*/
        temp=0;
        for(j=i+1;j<=N-1;j++)
        {
            temp=temp+x[j]*R[j*N+i];
        }
        /*quantize x[i] to integers*/
        x[i]=floor((y[i]-temp)/R[i*N+i]+0.5);
        
    }
    return;    
} 
