function [s_hat] = lra_df_regu(y,H,T,u)
%  Regularized lattice reduction aided decision feed back detector
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
% LRA-DF approximation to the problem
% min ||y -H s_hat||_2^2 + s_hat^T T s_hat
% s.t.  -u<=[s_hat]_i<=u, [s_hat]_i is an odd integer
%            for i=1,...,N.  
%
% usage : [s_hat] = lra_df_regu(y,H,T,u);
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- T - positive semi-definite regularization matrix of dimension N by N
% -- u - symbol bound that is a positive odd integer.
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

%number of tx symbols
N=size(H,2);

%triangularize the channel
R=chol(H'*H+T);
y=R'\(H'*y);

%shift and scale
y=(y+R*ones(N,1))/2;

%LLL reduction of channel R
[Qe,Re,Ue]=lll(eye(N),R,3/4);

%DF on the transformed domain
z=df(Qe'*y,Re);

%shift and scale
s_hat=2*Ue*z-1;

%apply symbol bound
s_hat=max(s_hat,-u);
s_hat=min(s_hat,u);
