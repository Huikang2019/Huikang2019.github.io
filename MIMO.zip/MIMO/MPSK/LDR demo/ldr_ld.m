function [s_hat] = ldr_ld(y,H,u,no_of_iter)
%   Lagrangian dual relaxation lattice decoding (LDR LD) detector
%   written by Jiaxian Pan and Wing-kin Ma
%   Last updated on 11/25/2011
%
%   Projected subgradient method for the problem
%   max d(lambda)
%   s.t. lambda>=0,
%   where lambda is of dimension N, and d(lambda) is defined as
%   d(lambda) = min ||y - H s||_2^2 + s^T D(lambda) s - u^2 lambda^T 1
%               s.t. s_i is an odd integer for i=1,...,N
%
% usage : [s_hat] = ldr_ld(y,H,u,no_of_iter);
% ========================================================================
%
% Input parameters :
% -- y - real-valued received signal vector of dimensions M by 1, 
% -- H - real-valued channel realization matrix of dimension M by N.
% -- u - symbol bound that is a positive odd integer.
% -- no_of_iter - number of maximum PS iterations
%
% Output parameters:
% -- s_hat detected symbol vector.
% =======================================================================

%parameter for choosing step size. Higher QAM size, smaller gamma.
if u==1
    gamma=0.05;
elseif u==3
    gamma=0.01;
elseif u==7
    gamma=0.002;
else
    gamma=0.0004;
end;


N=size(H,1);

%---------Box relaxation initilization----------------
%solve the problem via active set method
%             min ||y - H s||^2
%             s.t. -u <= s_i <= u, for all i

lambda=box_relaxation(y,H,u);
% lambda=zeros(m,1);
%----------------------------------------------------

%------------subgradient method----------------------
obj_best=inf;


HH=H'*H;Hy=H'*y;
Hy_HH1=Hy-sum(HH,2);
U=eye(N);
for k=1:no_of_iter
    %-----solve min_{s^N \in 2Z^N +1} \|y-Hs\|^2+ s^T Lambda s
 
    if k==1
        W=chol(HH+diag(lambda));
    else
        W=chol(U'*(HH+diag(lambda))*U);
    end;
    
    f=(W'\(U'*(Hy_HH1-lambda)))/2;
    
    [Q,R,U_tilde]=lll(eye(N),W,3/4);
    Temp=diag(sign(diag(R)));
    R=Temp*R;Q=Q*Temp;    
    
    
    %restore U
    if k~=1
        U=U*U_tilde;
    else
        U=U_tilde;
    end;
    
    f_tilde=Q'*f;

    %Solve by sphere decoder  min ||f- W z||_2
    %                         s.t. z is integer
    if k==1
        z0=round(W\f);
        radius_squared=norm(f-W*z0)^2+1e-7;
    else
        radius_squared=norm(f-W*z_tilde)^2+1e-7;        
    end
    
    [z_tilde,info]=sd_search(f_tilde,R,radius_squared,-inf,inf);
    
    %-----------choose the best candidate s------------
    %restore a primal feasible solution
    z=U*z_tilde;
    s=2*z+1;
    s_temp=min(max(s,-u),u);
    
    %check the objective value, and keep it if it is the best one
    obj_current=norm(y-H*s_temp);
    if (obj_current<=obj_best)
        obj_best=obj_current;
        s_hat=s_temp;
    end;
    
    
    %---------------update lambda---------------------
    %subgradient
    subgrad=s.^2-u*u;


    %stepsize
    steps=gamma/sqrt(k);
   
    %update lambda
    lambda_old=lambda;
    lambda=lambda+steps*subgrad;             %update lambda

    %if only marginal changes in lambda occur, exit
    lambda=max(lambda,0);
     if (norm(lambda_old-lambda)<=1e-9)
         break;
     end;
end
